install into resources/esx or where ever you install the non-required mods for esx

server config add start esx_vangelico_robbery

the png is an optional image for the jewels if you use inventoryhud

sale spot is here: 1347.32, 4389.87, 44.34 - X, Y, Z format for teleporting.