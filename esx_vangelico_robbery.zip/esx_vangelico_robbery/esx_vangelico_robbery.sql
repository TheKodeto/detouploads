INSERT INTO `items` (name, label, `limit`) VALUES
	('jewels', 'Jewels', -1)
;