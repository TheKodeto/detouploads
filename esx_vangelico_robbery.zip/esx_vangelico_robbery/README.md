# fxserver_esx_vangelico_robbery
FXserver ESX Vangelico Robbery

[REQUIREMENTS]

  * esx_policejob => https://github.com/FXServer-ESX/fxserver-esx_policejob

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
3) Import esx_vangelico_robbery.sql in your database
4) Add this in your server.cfg :

```
start esx_vangelico_robbery
```

[ORIGINAL SCRIPT]

  * esx_holdup => https://github.com/ESX-Org/esx_holdup

[VIDEO]

  * https://www.youtube.com/watch?v=MivP5hU5m8A





